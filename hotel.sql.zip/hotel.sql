-- phpMyAdmin SQL Dump
-- version 4.0.6deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 23, 2014 at 04:48 PM
-- Server version: 5.5.35-0ubuntu0.13.10.2
-- PHP Version: 5.5.3-1ubuntu2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_5f412f9a` (`group_id`),
  KEY `auth_group_permissions_83d7f98b` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  KEY `auth_permission_37ef4eb4` (`content_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can add permission', 2, 'add_permission'),
(5, 'Can change permission', 2, 'change_permission'),
(6, 'Can delete permission', 2, 'delete_permission'),
(7, 'Can add group', 3, 'add_group'),
(8, 'Can change group', 3, 'change_group'),
(9, 'Can delete group', 3, 'delete_group'),
(10, 'Can add user', 4, 'add_user'),
(11, 'Can change user', 4, 'change_user'),
(12, 'Can delete user', 4, 'delete_user'),
(13, 'Can add content type', 5, 'add_contenttype'),
(14, 'Can change content type', 5, 'change_contenttype'),
(15, 'Can delete content type', 5, 'delete_contenttype'),
(16, 'Can add session', 6, 'add_session'),
(17, 'Can change session', 6, 'change_session'),
(18, 'Can delete session', 6, 'delete_session'),
(22, 'Can add hotel', 8, 'add_hotel'),
(23, 'Can change hotel', 8, 'change_hotel'),
(24, 'Can delete hotel', 8, 'delete_hotel'),
(25, 'Can add reservation_ company', 9, 'add_reservation_company'),
(26, 'Can change reservation_ company', 9, 'change_reservation_company'),
(27, 'Can delete reservation_ company', 9, 'delete_reservation_company'),
(28, 'Can add reserved_ room', 10, 'add_reserved_room'),
(29, 'Can change reserved_ room', 10, 'change_reserved_room'),
(30, 'Can delete reserved_ room', 10, 'delete_reserved_room'),
(31, 'Can add company_ offer', 11, 'add_company_offer'),
(32, 'Can change company_ offer', 11, 'change_company_offer'),
(33, 'Can delete company_ offer', 11, 'delete_company_offer'),
(34, 'Can add comment', 12, 'add_comment'),
(35, 'Can change comment', 12, 'change_comment'),
(36, 'Can delete comment', 12, 'delete_comment'),
(37, 'Can add rate', 13, 'add_rate'),
(38, 'Can change rate', 13, 'change_rate'),
(39, 'Can delete rate', 13, 'delete_rate'),
(40, 'Can add hotel_ image', 14, 'add_hotel_image'),
(41, 'Can change hotel_ image', 14, 'change_hotel_image'),
(42, 'Can delete hotel_ image', 14, 'delete_hotel_image');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime NOT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(75) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$12000$A1ASGhdc8Eci$iAJRN55hA/mFaAPkFrs8YQFYrejrHaHiRPe/9/kbGUo=', '2014-04-23 15:07:09', 1, 'mosta', '', '', 'mosta@iti.com', 1, 1, '2014-04-19 18:45:51'),
(2, 'pbkdf2_sha256$12000$ea1sunc8Dwid$mJpKmxFVV66ofJUxLcS/dBE/A/LpWuoKNvdstPWtd0g=', '2014-04-23 15:03:09', 0, 'mostafa', '', '', '', 0, 1, '2014-04-21 08:37:23'),
(3, 'pbkdf2_sha256$12000$k5O2PPV6tnJO$xyLOS3QUgcUy5DMe7mKPDJvKjIXdKuOotLe1qLmimSY=', '2014-04-23 09:25:12', 0, 'mostafa1', '', '', '', 0, 1, '2014-04-21 08:38:10'),
(4, 'pbkdf2_sha256$12000$x2zyqA19zDQY$D3FaKNmuxHjJeqShgK3A2VK3yKhKv+nG/xfXjqD13UQ=', '2014-04-21 08:38:51', 0, 'mostafa2', '', '', '', 0, 1, '2014-04-21 08:38:51'),
(5, 'pbkdf2_sha256$12000$950weeS2UvOw$Q8TFMpNUIlynVEPI2gmV4TtcogtYu3fetKKRIXQWp/U=', '2014-04-22 13:24:33', 0, 'mostafa3', '', '', '', 0, 1, '2014-04-22 13:24:33');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_6340c63c` (`user_id`),
  KEY `auth_user_groups_5f412f9a` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_6340c63c` (`user_id`),
  KEY `auth_user_user_permissions_83d7f98b` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_6340c63c` (`user_id`),
  KEY `django_admin_log_37ef4eb4` (`content_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `user_id`, `content_type_id`, `object_id`, `object_repr`, `action_flag`, `change_message`) VALUES
(1, '2014-04-21 13:59:40', 1, 8, '1', 'Hotel object', 1, ''),
(2, '2014-04-21 14:28:20', 1, 9, '1', 'Reservation_Company object', 1, ''),
(3, '2014-04-21 14:29:16', 1, 11, '1', 'Company_Offer object', 1, ''),
(4, '2014-04-21 14:31:41', 1, 8, '2', 'Hotel object', 1, ''),
(5, '2014-04-21 15:21:15', 1, 10, '1', 'Reserved_Room object', 1, ''),
(6, '2014-04-22 12:10:19', 1, 8, '1', 'Hotel object', 1, ''),
(7, '2014-04-22 12:14:24', 1, 8, '2', 'Hotel object', 1, ''),
(8, '2014-04-22 15:52:09', 1, 8, '3', 'Zamalek-Hilton', 1, ''),
(9, '2014-04-22 19:26:31', 1, 14, '1', 'Hotel_Image object', 1, ''),
(10, '2014-04-22 19:27:14', 1, 14, '2', 'Hotel_Image object', 1, ''),
(11, '2014-04-22 19:27:27', 1, 14, '3', 'Hotel_Image object', 1, ''),
(12, '2014-04-22 19:28:01', 1, 12, '1', 'Comment object', 1, ''),
(13, '2014-04-22 19:28:28', 1, 12, '2', 'Comment object', 1, ''),
(14, '2014-04-22 19:28:47', 1, 12, '3', 'Comment object', 1, ''),
(15, '2014-04-22 19:32:43', 1, 13, '1', 'Rate object', 1, ''),
(16, '2014-04-22 19:32:52', 1, 13, '2', 'Rate object', 1, ''),
(17, '2014-04-23 04:49:37', 1, 9, '1', 'Reservation_Company object', 1, ''),
(18, '2014-04-23 04:50:28', 1, 11, '1', 'Company_Offer object', 1, ''),
(19, '2014-04-23 09:21:41', 1, 11, '2', 'Company_Offer object', 1, ''),
(20, '2014-04-23 09:23:54', 1, 12, '8', 'Comment object', 2, 'Changed comment.'),
(21, '2014-04-23 09:24:13', 1, 12, '7', 'Comment object', 2, 'Changed comment.'),
(22, '2014-04-23 09:24:22', 1, 12, '6', 'Comment object', 2, 'Changed comment.'),
(23, '2014-04-23 09:24:31', 1, 12, '3', 'Comment object', 2, 'Changed comment.'),
(24, '2014-04-23 09:24:42', 1, 12, '2', 'Comment object', 2, 'Changed comment.'),
(25, '2014-04-23 09:24:51', 1, 12, '1', 'Comment object', 2, 'Changed comment.');

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_label` (`app_label`,`model`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `name`, `app_label`, `model`) VALUES
(1, 'log entry', 'admin', 'logentry'),
(2, 'permission', 'auth', 'permission'),
(3, 'group', 'auth', 'group'),
(4, 'user', 'auth', 'user'),
(5, 'content type', 'contenttypes', 'contenttype'),
(6, 'session', 'sessions', 'session'),
(8, 'hotel', 'reserve', 'hotel'),
(9, 'reservation_ company', 'reserve', 'reservation_company'),
(10, 'reserved_ room', 'reserve', 'reserved_room'),
(11, 'company_ offer', 'reserve', 'company_offer'),
(12, 'comment', 'reserve', 'comment'),
(13, 'rate', 'reserve', 'rate'),
(14, 'hotel_ image', 'reserve', 'hotel_image');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_b7b81f0c` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('u39jyq1z3zd4hpml5unlery0ukbvc3rf', 'YWRjMmRkNWNhODVmOTI4NzEzZWIxZGFiMTg1ZDllMTdjZTBlMzcxNzp7InRlc3Rjb29raWUiOiJ3b3JrZWQiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjEsIm1lbWJlcl9pZCI6Im1vc3RhIn0=', '2014-05-07 16:43:19'),
('xgrrc53bxtunlt6yssywwtz0puwimx2a', 'NGYyYjM0NjNkZWM0ZDM1ZWY3N2MwYzIxZTJlYzA3NzA1ZjRlMGExOTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MiwibWVtYmVyX2lkIjoyfQ==', '2014-05-05 21:58:03');

-- --------------------------------------------------------

--
-- Table structure for table `reserve_comment`
--

CREATE TABLE IF NOT EXISTS `reserve_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comment` varchar(500) NOT NULL,
  `hotel_f_id_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reserve_comment_d19ab116` (`hotel_f_id_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `reserve_comment`
--

INSERT INTO `reserve_comment` (`id`, `comment`, `hotel_f_id_id`) VALUES
(1, 'mosta:I spent a nice days there', 1),
(2, 'mostafa:I see a Nile every day', 1),
(3, 'mostafa2:A very very nice hotel', 1),
(6, 'mosta:Nice Hotel, Nice service', 1),
(7, 'mostafa2:Nice Hotel, Nice service', 1),
(8, 'mostafa1:Nice Hotel, Nice service', 1),
(9, 'mostafa:hhhhhhhhh', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reserve_company_offer`
--

CREATE TABLE IF NOT EXISTS `reserve_company_offer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `company_f_id_id` int(11) NOT NULL,
  `hotel_f_id_id` int(11) NOT NULL,
  `discount` double NOT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reserve_company_offer_7b059c92` (`company_f_id_id`),
  KEY `reserve_company_offer_d19ab116` (`hotel_f_id_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `reserve_company_offer`
--

INSERT INTO `reserve_company_offer` (`id`, `company_name`, `company_f_id_id`, `hotel_f_id_id`, `discount`, `start`, `end`) VALUES
(1, 'Mostafaco', 1, 2, 20, '2014-04-23', '2014-05-28'),
(2, 'Abdo travel', 1, 2, 15, '2014-07-01', '2014-08-01');

-- --------------------------------------------------------

--
-- Table structure for table `reserve_hotel`
--

CREATE TABLE IF NOT EXISTS `reserve_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_name` varchar(150) NOT NULL,
  `hotel_add` varchar(250) NOT NULL,
  `single_price` double NOT NULL,
  `num_of_singles` int(11) NOT NULL,
  `double_price` double NOT NULL,
  `num_of_doubles` int(11) NOT NULL,
  `triple_price` double NOT NULL,
  `num_of_triples` int(11) NOT NULL,
  `suite_price` double NOT NULL,
  `num_of_suites` int(11) NOT NULL,
  `hotel_url` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `reserve_hotel`
--

INSERT INTO `reserve_hotel` (`id`, `hotel_name`, `hotel_add`, `single_price`, `num_of_singles`, `double_price`, `num_of_doubles`, `triple_price`, `num_of_triples`, `suite_price`, `num_of_suites`, `hotel_url`) VALUES
(1, 'Ramses-Hilton', 'Egypt, Cairo', 100, 30, 150, 25, 250, 20, 500, 15, 'http://www3.hilton.com/en/hotels/egypt/ramses-hilton-CAIRHTW/index.html'),
(2, 'Grand Nile Tower', 'Corniche El Nil, Garden City, Cairo, Egypt', 200, 30, 400, 20, 500, 15, 700, 10, 'http://www.grandniletower.com/reservegypt/grandniletower/default.aspx'),
(3, 'Zamalek-Hilton', '21 MOHAMED MAZHAR STREET,  CAIRO,  11211,  EGYPT', 150, 30, 250, 20, 400, 20, 700, 15, 'http://www3.hilton.com/en/hotels/egypt/hilton-cairo-zamalek-residences-CAIZRHI/index.html');

-- --------------------------------------------------------

--
-- Table structure for table `reserve_hotel_image`
--

CREATE TABLE IF NOT EXISTS `reserve_hotel_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(100) NOT NULL,
  `hotel_f_id_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reserve_hotel_image_d19ab116` (`hotel_f_id_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `reserve_hotel_image`
--

INSERT INTO `reserve_hotel_image` (`id`, `image`, `hotel_f_id_id`) VALUES
(1, 'images/hi_exterior02_1_675x359_FitToBoxSmallDimension_Center.jpg', 1),
(2, 'images/hi_twinguestroom01_3_675x359_FitToBoxSmallDimension_Center.jpg', 1),
(3, 'images/hi_bathroom01_4_675x359_FitToBoxSmallDimension_Center.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `reserve_rate`
--

CREATE TABLE IF NOT EXISTS `reserve_rate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rate` varchar(5) NOT NULL,
  `hotel_f_id_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reserve_rate_d19ab116` (`hotel_f_id_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=51 ;

--
-- Dumping data for table `reserve_rate`
--

INSERT INTO `reserve_rate` (`id`, `rate`, `hotel_f_id_id`) VALUES
(1, '4', 1),
(2, '3', 1),
(6, '5', 1),
(7, '5', 1),
(8, '5', 1),
(9, '1', 1),
(10, '1', 1),
(11, '1', 1),
(12, '1', 1),
(13, '1', 1),
(14, '1', 1),
(15, '1', 1),
(16, '1', 1),
(17, '1', 1),
(18, '1', 1),
(19, '1', 1),
(20, '1', 1),
(21, '1', 1),
(22, '1', 1),
(23, '1', 1),
(24, '1', 1),
(25, '1', 1),
(26, '1', 1),
(27, '1', 1),
(28, '1', 1),
(29, '1', 1),
(30, '1', 1),
(31, '1', 1),
(32, '1', 1),
(33, '1', 1),
(34, '1', 1),
(35, '1', 1),
(36, '1', 1),
(37, '1', 1),
(38, '1', 1),
(39, '1', 1),
(40, '1', 1),
(41, '1', 1),
(42, '1', 1),
(43, '1', 1),
(44, '1', 2),
(45, '1', 2),
(46, '1', 2),
(47, '1', 2),
(48, '1', 2),
(49, '1', 2),
(50, '1', 2);

-- --------------------------------------------------------

--
-- Table structure for table `reserve_reservation_company`
--

CREATE TABLE IF NOT EXISTS `reserve_reservation_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) NOT NULL,
  `company_contact` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `reserve_reservation_company`
--

INSERT INTO `reserve_reservation_company` (`id`, `company_name`, `company_contact`) VALUES
(1, 'Mostafaco', 'ITI, Giza, Egypt');

-- --------------------------------------------------------

--
-- Table structure for table `reserve_reserved_room`
--

CREATE TABLE IF NOT EXISTS `reserve_reserved_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_f_id_id` int(11) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `check_in_date` date NOT NULL,
  `check_out_date` date NOT NULL,
  `num_of_rooms` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `reserve_reserved_room_d19ab116` (`hotel_f_id_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `reserve_reserved_room`
--

INSERT INTO `reserve_reserved_room` (`id`, `hotel_f_id_id`, `room_type`, `check_in_date`, `check_out_date`, `num_of_rooms`) VALUES
(1, 1, 'single', '2014-04-24', '2014-04-26', 2);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `group_id_refs_id_f4b32aac` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `permission_id_refs_id_6ba0f519` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `content_type_id_refs_id_d043b34a` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `group_id_refs_id_274b862c` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `user_id_refs_id_40c41112` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `permission_id_refs_id_35d9ac25` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `user_id_refs_id_4dc23c39` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `content_type_id_refs_id_93d2d1f8` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `user_id_refs_id_c0d12874` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `reserve_comment`
--
ALTER TABLE `reserve_comment`
  ADD CONSTRAINT `hotel_f_id_id_refs_id_bd99f46d` FOREIGN KEY (`hotel_f_id_id`) REFERENCES `reserve_hotel` (`id`);

--
-- Constraints for table `reserve_company_offer`
--
ALTER TABLE `reserve_company_offer`
  ADD CONSTRAINT `company_f_id_id_refs_id_70db2de6` FOREIGN KEY (`company_f_id_id`) REFERENCES `reserve_reservation_company` (`id`),
  ADD CONSTRAINT `hotel_f_id_id_refs_id_62d9b33a` FOREIGN KEY (`hotel_f_id_id`) REFERENCES `reserve_hotel` (`id`);

--
-- Constraints for table `reserve_hotel_image`
--
ALTER TABLE `reserve_hotel_image`
  ADD CONSTRAINT `hotel_f_id_id_refs_id_21e52c54` FOREIGN KEY (`hotel_f_id_id`) REFERENCES `reserve_hotel` (`id`);

--
-- Constraints for table `reserve_rate`
--
ALTER TABLE `reserve_rate`
  ADD CONSTRAINT `hotel_f_id_id_refs_id_7de7376f` FOREIGN KEY (`hotel_f_id_id`) REFERENCES `reserve_hotel` (`id`);

--
-- Constraints for table `reserve_reserved_room`
--
ALTER TABLE `reserve_reserved_room`
  ADD CONSTRAINT `hotel_f_id_id_refs_id_25de973a` FOREIGN KEY (`hotel_f_id_id`) REFERENCES `reserve_hotel` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
